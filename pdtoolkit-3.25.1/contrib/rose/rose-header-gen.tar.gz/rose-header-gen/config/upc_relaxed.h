/* This header asserts the upc relaxed pragma and includes upc.h 
 *
 *
 * Liao
 * 6/9/2008
 */
#ifndef upc_relaxed_INCLUDED
#define upc_relaxed_INCLUDED

#pragma upc relaxed
#include "upc.h"

#endif

