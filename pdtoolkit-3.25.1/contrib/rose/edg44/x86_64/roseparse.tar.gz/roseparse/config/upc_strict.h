/* This header asserts the upc strict pragma and includes upc.h 
 *
 *
 * Liao
 * 6/9/2008
 */

#ifndef upc_strict_INCLUDED
#define upc_strict_INCLUDED

#pragma upc strict
#include "upc.h"

#endif

